<header class="top-nav">
    <nav>
        <ul>

            <li><a href="<?php echo e(route('AdminIndex')); ?>">Clients</a></li>
            <li><a href="<?php echo e(route('logout')); ?>">Log Out</a></li>

        </ul>
    </nav>
</header>
