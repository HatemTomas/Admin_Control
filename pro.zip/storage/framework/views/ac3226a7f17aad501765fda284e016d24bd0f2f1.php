<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form action="<?php echo e(route('addService',['client' => $client])); ?>" method="post">
            <div class="input-group">
                <label for="title">Title</label>
                <input type="text" name="title" id="title"
                       <?php echo e($errors->has('title') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('title')); ?>">
            </div>
            <div class="input-group">
                <label for="type">Type</label>
                <input type="text" name="type" id="type"
                       <?php echo e($errors->has('type') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('type')); ?>">
            </div>
            <div class="input-group">
                <label for="link">link</label>
                <input type="text" name="link" id="link"
                       <?php echo e($errors->has('link') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('link')); ?>">
            </div>
            <div class="input-group">
                <label for="description">description</label>
                <input type="text" name="description" id="description"
                       <?php echo e($errors->has('description') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('description')); ?>">
            </div>

            <button type="submit" class="btn">Add</button>
            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('is/post.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>