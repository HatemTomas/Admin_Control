<?php $__env->startSection('content'); ?>
    <div class="container">
        <section>
            <a href="<?php echo e(route('EditService',['client' => $client,'service_id'=>$service->id])); ?>">Edit </a>
            <a href="<?php echo e(route('doDeleteService',['client' => $client,'service_id'=>$service->id])); ?>">Delete </a>
        </section>
        <section class="post">
            <h1> Title :<?php echo e($service->title); ?></h1>
            <span> Type : <?php echo e($service->type); ?></span><br/>
            <span> User Id : <?php echo e($service->user_id); ?></span> <br/>
            <span> Link: <?php echo e($service->link); ?></span> <br/>
            <span> Description: <?php echo e($service->description); ?></span>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>