<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/modal.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="card">
            <header>
                <nav>
                    <ul>
                        <li><a href="<?php echo e(route('addClientPage')); ?>" class="btn">New Client</a></li>

                    </ul>
                </nav>
            </header>
            <section class="list">
                <?php if(count($clients)==0): ?>
                    No Clients
                <?php else: ?>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article>
                            <div class="post-info">
                                <h3><?php echo e($client->title); ?></h3>
                                <span class="info"> <?php echo e($client->description); ?> | <?php echo e($client->phone); ?></span>
                            </div>
                            <div class="edit">
                                <nav>
                                    <ul>
                                        <li><a href="<?php echo e(route('viewClient',['client_id'=>$client->id])); ?>">View Client</a></li>
                                        <li><a href="<?php echo e(route('EditClient',['client_id'=>$client->id])); ?>">Edit</a></li>
                                        <li><a href="<?php echo e(route('DeleteClient',['client_id'=>$client->id])); ?>" class="danger">Delete</a></li>
                                        <li><a href="<?php echo e(route('ServicesPage',['client'=>$client->id])); ?>">Manage Services</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </section>
        </div>

    </div>

    <div class="modal" id="contact-massage-info">
        <button class="btn" id="modal-close">Close</button>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var token ="<?php echo e(Session::token()); ?>";
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/modal.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/contact_massages.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>