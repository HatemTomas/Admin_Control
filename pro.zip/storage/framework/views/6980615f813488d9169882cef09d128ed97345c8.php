<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/modal.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="card">
            <header>
                <nav>
                    <ul>
                        <li><a href="<?php echo e(route('addService',['client' => $client])); ?>" class="btn">New Service</a></li>

                    </ul>
                </nav>
            </header>
            <section class="list">
                <?php if(count($services)==0): ?>
                    No Services
                <?php else: ?>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article>
                            <div class="post-info">
                                <h3><?php echo e($service->title); ?></h3>
                                <span class="info"> <?php echo e($service->type); ?> | <?php echo e($service->link); ?></span>
                            </div>
                            <div class="edit">
                                <nav>
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('viewService',['client' => $client,'service_id'=>$service->id])); ?>">View</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('EditService',['client' => $client,'service_id'=>$service->id])); ?>">Edit</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('doDeleteService',['client' => $client,'service_id'=>$service->id])); ?>"
                                               class="danger">Delete</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </section>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var token = "<?php echo e(Session::token()); ?>";
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/modal.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/contact_massages.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>