<?php $__env->startSection('content'); ?>
    <div class="container">
        <section>
            <a href="<?php echo e(route('EditClient',['client_id'=>$client->id])); ?>">Edit Post</a>
            <a href="<?php echo e(route('DeleteClient',['client_id'=>$client->id])); ?>">Delete Post</a>
        </section>
        <section class="post">
            <h1> Title :<?php echo e($client->title); ?></h1>
            <span> Description : <?php echo e($client->description); ?></span><br/>
            <span> Phone : <?php echo e($client->phone); ?></span> <br/>
            <span> Status: <?php echo e($client->status); ?></span> <br/>
            <span>Contract start date : <?php echo e($client->contract_start_date); ?></span> <br/>
             <span>Contract end date :   <?php echo e($client->contract_end_date); ?></span>

        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>