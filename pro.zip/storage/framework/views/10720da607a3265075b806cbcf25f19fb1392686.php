<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form action="<?php echo e(route('AddClient')); ?>" method="post">
            <div class="input-group">
                <label for="title">Title</label>
                <input type="text" name="title" id="title"
                       <?php echo e($errors->has('title') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('title')); ?>">
            </div>
            <div class="input-group">
                <label for="description">Description</label>
                <input type="text" name="description" id="description"
                       <?php echo e($errors->has('description') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('description')); ?>">
            </div>
            <div class="input-group">
                <label for="status">Status</label>
                <input type="text" name="status" id="status"
                       <?php echo e($errors->has('status') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('status')); ?>">
            </div>
            <div class="input-group">
                <label for="phone">Phone</label>
                <input type="text" name="phone" id="phone"
                       <?php echo e($errors->has('phone') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('phone')); ?>">
            </div>
            <div class="input-group">
                <label for="contract_start_date">Contract Start Date</label>
                <input type="date" name="contract_start_date" id="contract_start_date"
                       <?php echo e($errors->has('contract_start_date') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('contract_start_date')); ?>">
            </div>
            <div class="input-group">
                <label for="contract_end_date">Contract End Date</label>
                <input type="date" name="contract_end_date" id="contract_end_date"
                       <?php echo e($errors->has('contract_end_date') ? 'class=has-error' : ''); ?>value="<?php echo e(Request::old('contract_end_date')); ?>">
            </div>
            <div class="form-group">
                <div class="input-group">
                    <label>facebook</label>
                    <input type="checkbox" name="service[]" value="facebook">
                </div>
                <div class="input-group">
                    <label>twitter</label>
                    <input type="checkbox" name="service[]" value="twitter">
                </div>
                <div class="input-group">
                    <label>instagram</label>
                    <input type="checkbox" name="service[]" value="instagram">
                </div>
                <div class="input-group">
                    <label>youtube</label>
                    <input type="checkbox" name="service[]" value="youtube">
                </div>
            </div>


            <button type="submit" class="btn">Add</button>
            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('is/post.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>