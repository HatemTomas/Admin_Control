<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form action="<?php echo e(route('doEditClient')); ?>" method="post">
            <div class="input-group">
                <label for="title">Title</label>
                <input type="text" name="title" id="title" <?php echo e($errors->has('title') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('title')? Request::old('title') : isset($client) ? $client->title : ''); ?>" >
            </div>
            <div class="input-group">
                <label for="description">Description</label>
                <input type="text" name="description" id="description" <?php echo e($errors->has('description') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('description')? Request::old('description') : isset($client) ? $client->description : ''); ?>" >
            </div>
            <div class="input-group">
                <label for="status">Status</label>
                <input type="text" name="status" id="status" <?php echo e($errors->has('status') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('status')? Request::old('status') : isset($client) ? $client->status : ''); ?>" >
            </div>
            <div class="input-group">
                <label for="phone">Phone</label>
                <input type="text" name="phone" id="phone" <?php echo e($errors->has('phone') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('phone')? Request::old('phone') : isset($client) ? $client->phone : ''); ?>" >
            </div>
            <div class="input-group">
                <label for="contract_start_date">Contract Start Date</label>
                <input type="date" name="contract_start_date" id="contract_start_date" <?php echo e($errors->has('contract_start_date') ? 'class=has-error' : ''); ?> value="<?php echo e(Request::old('contract_start_date')? Request::old('contract_start_date') : isset($client) ? $client->contract_start_date : ''); ?>" >
            </div>
            <div class="input-group">
                <label for="contract_end_date">Contract End Date</label>
                <input type="date" name="contract_end_date" id="contract_end_date" <?php echo e($errors->has('contract_end_date') ? 'class=has-error' : ''); ?>value="<?php echo e(Request::old('contract_end_date')? Request::old('contract_end_date') : isset($client) ? $client->contract_end_date : ''); ?>">
            </div>

            <button type="submit" class="btn">Edit</button>
            <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
            <input type="hidden" name="client_id" value="<?php echo e($client->id); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('is/post.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>