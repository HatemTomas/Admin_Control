<footer class="main-footer">
    <nav>
        <ul>

        </ul>
    </nav>
</footer>