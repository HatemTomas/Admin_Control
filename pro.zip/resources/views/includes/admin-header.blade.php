<header class="top-nav">
    <nav>
        <ul>

            <li><a href="{{route('AdminIndex')}}">Clients</a></li>
            <li><a href="{{route('logout')}}">Log Out</a></li>

        </ul>
    </nav>
</header>
