<header>
    <nav class="main-nav">
        <ul>

        </ul>
    </nav>
</header>